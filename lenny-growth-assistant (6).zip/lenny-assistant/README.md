# The Lenny Growth Assistant

A grounded RAG chatbot over Lenny's Podcast transcripts, with a Ship 30
for 30 essay-generation skill and a Claude-Artifacts-style side panel.
Built for the Forward Deployed Engineer take-home.

See `docs/PRD.md`, `docs/design.md`, and `docs/architecture.md` for the
full discovery brief, UI/UX rationale, and technical architecture
(including the trade-offs made — read the PRD's "Assumptions" and "Scope
choices" sections first if you're evaluating this).

## Architecture overview

```
frontend (nginx, static HTML/JS)  ──▶  backend (FastAPI)  ──▶  PostgreSQL + pgvector
                                              │
                                              ├─▶ Ollama (local, mandatory for the demo)
                                              └─▶ Anthropic API (cloud, opt-in)
```

- **Backend:** FastAPI, async SQLAlchemy, PostgreSQL + pgvector (one
  database for both persistence and vector search).
- **Agent layer:** a bounded Anthropic Messages API tool-use loop (not the
  full Claude Agent SDK — see `docs/architecture.md` §5 for why).
- **Frontend:** dependency-free HTML/CSS/JS, served via nginx in its own
  container. No build step.
- **Deployment:** `docker-compose up` — Postgres, Ollama, backend,
  frontend all start together.

## Prerequisites

- Docker Desktop (or Docker Engine + Compose v2)
- ~10 GB free disk (Postgres + Ollama image + an 8B model)
- 16 GB RAM recommended for comfortable local Ollama inference
- (Optional) an Anthropic API key, only needed if you want to use the
  cloud provider

## Setup

1. **Copy the env file and fill it in:**
   ```bash
   cp .env.example .env
   # Optionally set ANTHROPIC_API_KEY if you want the cloud provider
   ```

2. **Add transcripts.** Drop `.txt` or `.md` files into
   `backend/transcripts/`. A line like `Episode: <title>` and
   `Guest: <name>` at the top of a file is picked up as metadata if
   present (optional — ingestion works without it).

3. **Start everything:**
   ```bash
   docker-compose up --build
   ```

4. **Pull a local model for Ollama (one-time, in a second terminal):**
   ```bash
   docker exec -it lenny_ollama ollama pull llama3.1:8b
   ```

5. **Ingest transcripts (one-time, or whenever you add new files):**
   ```bash
   docker exec -it lenny_backend python -m scripts.ingest
   ```

6. **Open the app:** http://localhost:3000

   Check backend health directly at http://localhost:8000/api/health —
   it reports DB, Ollama, and Anthropic-key status individually.

## Running without Docker (local dev)

```powershell
# Backend
cd backend
pip install -r requirements.txt
# Requires a Postgres+pgvector instance reachable at DATABASE_URL
$env:DATABASE_URL="postgresql+asyncpg://postgres:postgres@localhost:5432/lenny_assistant"
python -m scripts.ingest
python -m uvicorn app.main:app --reload

# Frontend — just open frontend/index.html, or serve it:
cd frontend
python -m http.server 3000
```

## Switching providers

The model dropdown in the UI switches providers per message
(`provider_override` in the chat request) — no restart needed. The
default for new sessions is set by `DEFAULT_LLM_PROVIDER` in `.env`.

## Tests

```bash
cd backend
pytest -v
```

`test_api.py` and `test_retrieval.py`/`test_providers.py` need a
reachable Postgres+pgvector instance for the integration tests; the
retrieval-threshold and provider-init tests are pure unit tests and don't.
A short manual UI test plan:

1. Ask a question covered by an ingested transcript → expect a cited
   answer.
2. Ask something unrelated (e.g. "what's the weather today?") → expect
   the explicit "I do not have sufficient information..." response.
3. Click "Ship 30 Essay" on a covered question → expect a formatted essay
   in the right-hand panel.
4. Switch the provider dropdown to "Claude" without an API key set →
   expect a readable 503 error bubble, not a hang.
5. Stop the `ollama` container, ask a question on the Ollama provider →
   expect a readable error naming Ollama as unreachable.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| `/api/health` shows `database: error` | Postgres isn't up yet, or `DATABASE_URL` is wrong |
| `/api/health` shows `ollama: unreachable` | `ollama` container isn't running, or the model hasn't been pulled |
| Chat returns 503 mentioning Ollama | Same as above — check `docker exec -it lenny_ollama ollama list` |
| Chat returns 503 mentioning Anthropic | `ANTHROPIC_API_KEY` missing/invalid in `.env` |
| "I do not have sufficient information..." on everything | Ingestion hasn't run yet, or the threshold is too strict — check `RETRIEVAL_SIMILARITY_THRESHOLD` |
| Frontend shows "Could not reach backend" | Backend container isn't up, or you're opening `index.html` from a different host than `localhost` (the frontend hardcodes `http://localhost:8000`) |

## Known simplifications (documented, not hidden)

See `docs/PRD.md` §4 "Scope choices" and `docs/architecture.md` for the
full list — notably: no auth, manual (not scraped) transcript ingestion,
table creation instead of Alembic migrations, and a reference-only raw
HTML artifact renderer not yet wired to a chat mode.
