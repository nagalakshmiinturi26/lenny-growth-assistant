# Agent transcripts

Per the assignment's deliverables list, this folder should contain the
coding-agent session logs used while building this project — including
failed attempts and how they were corrected — with secrets removed before
committing.

Suggested naming: `01_initial_scaffolding.md`, `02_debugging_pgvector.md`,
etc., one file per work session, in chronological order.

This repo doesn't ship pre-filled logs here since they need to reflect
your actual build session(s). Export your coding-agent conversation(s)
into this folder before submitting, redacting any API keys or personal
paths first.
