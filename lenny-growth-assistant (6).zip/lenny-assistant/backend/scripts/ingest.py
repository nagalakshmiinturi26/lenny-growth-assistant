"""
Ingest transcript files (.txt / .md) from backend/transcripts/ into the
pgvector-backed transcript_chunks table. Safe to re-run: it deletes
existing chunks for a source file before re-inserting, so it won't
duplicate on repeated runs.

Usage:
    python -m scripts.ingest
"""
import asyncio
import os
import re
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import delete, text  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.database import AsyncSessionLocal, engine  # noqa: E402
from app.models.db_models import Base, TranscriptChunk  # noqa: E402
from app.rag.embeddings import embed_text  # noqa: E402

TRANSCRIPTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "transcripts")
CHUNK_SIZE = 700
CHUNK_OVERLAP = 100


def chunk_text(raw: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    chunks, start = [], 0
    while start < len(raw):
        chunks.append(raw[start : start + size])
        start += size - overlap
    return [c for c in chunks if c.strip()]


def parse_metadata(text_block: str) -> dict:
    """Best-effort extraction of 'Episode: ...' / 'Guest: ...' header lines, if present."""
    episode = re.search(r"^Episode:\s*(.+)$", text_block, re.MULTILINE)
    guest = re.search(r"Guest(?:s)?:\s*([^\n]+)", text_block, re.MULTILINE)
    return {
        "episode_title": episode.group(1).strip() if episode else "",
        "guest_name": guest.group(1).strip() if guest else "",
    }


async def main():
    settings = get_settings()

    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.create_all)

    if not os.path.isdir(TRANSCRIPTS_DIR):
        print(f"No transcripts/ folder found at {TRANSCRIPTS_DIR}")
        return

    files = [f for f in os.listdir(TRANSCRIPTS_DIR) if f.endswith((".txt", ".md"))]
    if not files:
        print(f"No .txt/.md files found in {TRANSCRIPTS_DIR}")
        return

    total = 0
    async with AsyncSessionLocal() as db:
        for fname in files:
            path = os.path.join(TRANSCRIPTS_DIR, fname)
            raw = open(path, encoding="utf-8").read()
            meta = parse_metadata(raw)
            chunks = chunk_text(raw)

            await db.execute(delete(TranscriptChunk).where(TranscriptChunk.source_file == fname))

            for i, chunk in enumerate(chunks):
                vector = embed_text(chunk, settings.embedding_model)
                db.add(
                    TranscriptChunk(
                        source_file=fname,
                        episode_title=meta["episode_title"],
                        guest_name=meta["guest_name"],
                        chunk_index=i,
                        chunk_text=chunk,
                        embedding=vector,
                    )
                )
            await db.commit()
            print(f"  {fname}: {len(chunks)} chunks")
            total += len(chunks)

    print(f"\nDone. Indexed {total} chunks from {len(files)} file(s).")


if __name__ == "__main__":
    asyncio.run(main())
