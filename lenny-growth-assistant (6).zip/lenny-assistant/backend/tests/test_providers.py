import pytest

from app.providers.base import ProviderUnavailableError
from app.providers.cloud_provider import AnthropicProvider


def test_anthropic_provider_requires_api_key():
    with pytest.raises(ProviderUnavailableError):
        AnthropicProvider(api_key="", model="claude-sonnet-4-5")


def test_anthropic_provider_initializes_with_key():
    provider = AnthropicProvider(api_key="sk-fake-for-test", model="claude-sonnet-4-5")
    assert provider.name == "claude"
