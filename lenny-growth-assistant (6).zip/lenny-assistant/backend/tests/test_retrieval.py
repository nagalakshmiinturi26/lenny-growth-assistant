"""
Unit tests for the retriever's out-of-domain and threshold behavior.
Requires a Postgres+pgvector test instance with at least one ingested
transcript chunk (run scripts/ingest.py against a test DB first, or mock
the DB session — the assertions below focus on the threshold-filtering
logic in isolation from the embedding model itself).
"""
import pytest

from app.rag.retriever import TranscriptRetriever


class _FakeChunk:
    def __init__(self, source_file, chunk_text, episode_title="", guest_name=""):
        self.source_file = source_file
        self.chunk_text = chunk_text
        self.episode_title = episode_title
        self.guest_name = guest_name


@pytest.mark.asyncio
async def test_retrieve_drops_low_similarity_chunks(monkeypatch):
    """Chunks below retrieval_similarity_threshold must be excluded."""

    class _FakeResult:
        def all(self):
            return [(_FakeChunk("relevant.txt", "on-topic passage"), 0.1),  # similarity 0.9
                    (_FakeChunk("irrelevant.txt", "off-topic passage"), 0.9)]  # similarity 0.1

    class _FakeDB:
        async def execute(self, stmt):
            return _FakeResult()

    retriever = TranscriptRetriever(_FakeDB())
    retriever.settings.retrieval_similarity_threshold = 0.3

    monkeypatch.setattr("app.rag.retriever.embed_text", lambda text, model: [0.0] * 384)

    results = await retriever.retrieve("test query")

    assert len(results) == 1
    assert results[0]["source"] == "relevant.txt"


@pytest.mark.asyncio
async def test_retrieve_returns_empty_list_when_nothing_matches(monkeypatch):
    class _FakeResult:
        def all(self):
            return []

    class _FakeDB:
        async def execute(self, stmt):
            return _FakeResult()

    retriever = TranscriptRetriever(_FakeDB())
    monkeypatch.setattr("app.rag.retriever.embed_text", lambda text, model: [0.0] * 384)

    results = await retriever.retrieve("anything")
    assert results == []
