"""
Integration tests against a running Postgres (pgvector) instance.
Requires DATABASE_URL to point at a test database before running:
    pytest tests/ -v
"""
import uuid

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.mark.asyncio
async def test_health_endpoint(client):
    resp = await client.get("/api/health")
    assert resp.status_code == 200
    body = resp.json()
    assert "database" in body
    assert "ollama" in body


@pytest.mark.asyncio
async def test_create_and_fetch_session(client):
    resp = await client.post("/api/sessions", json={"title": "Test session", "llm_provider": "ollama"})
    assert resp.status_code == 201
    session = resp.json()
    assert session["title"] == "Test session"

    resp2 = await client.get(f"/api/sessions/{session['id']}")
    assert resp2.status_code == 200
    assert resp2.json()["messages"] == []


@pytest.mark.asyncio
async def test_chat_with_nonexistent_session_returns_404(client):
    fake_id = str(uuid.uuid4())
    resp = await client.post("/api/chat", json={"session_id": fake_id, "message": "hello", "mode": "default"})
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_chat_rejects_empty_message(client):
    session_resp = await client.post("/api/sessions", json={"title": "t", "llm_provider": "ollama"})
    session_id = session_resp.json()["id"]

    resp = await client.post("/api/chat", json={"session_id": session_id, "message": "", "mode": "default"})
    assert resp.status_code == 422  # pydantic min_length validation
