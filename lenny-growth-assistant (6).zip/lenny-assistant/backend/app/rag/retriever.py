import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.db_models import TranscriptChunk
from app.rag.embeddings import embed_text

logger = logging.getLogger("lenny.retriever")


class TranscriptRetriever:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.settings = get_settings()

    async def retrieve(self, query: str) -> list[dict]:
        """
        Cosine-distance search over pgvector. pgvector's `<=>` operator is
        cosine distance, so similarity = 1 - distance. Chunks below the
        configured threshold are dropped — the caller is responsible for
        telling the user when nothing relevant came back (see agent.py's
        "insufficient information" behavior).
        """
        query_vector = embed_text(query, self.settings.embedding_model)

        distance = TranscriptChunk.embedding.cosine_distance(query_vector)
        stmt = (
            select(TranscriptChunk, distance.label("distance"))
            .order_by(distance)
            .limit(self.settings.retrieval_top_k)
        )
        result = await self.db.execute(stmt)
        rows = result.all()

        chunks = []
        for chunk, dist in rows:
            similarity = 1 - float(dist)
            if similarity < self.settings.retrieval_similarity_threshold:
                continue
            chunks.append(
                {
                    "text": chunk.chunk_text,
                    "source": chunk.source_file,
                    "episode": chunk.episode_title,
                    "guest": chunk.guest_name,
                    "similarity": round(similarity, 3),
                }
            )
        return chunks
