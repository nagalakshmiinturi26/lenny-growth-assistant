"""
Embeddings run locally via sentence-transformers — no API key needed, and
it means retrieval still works even when the cloud LLM provider is down
(only generation would fail, not search).
"""
from functools import lru_cache

from sentence_transformers import SentenceTransformer


@lru_cache
def get_embedder(model_name: str) -> SentenceTransformer:
    return SentenceTransformer(model_name)


def embed_text(text: str, model_name: str) -> list[float]:
    model = get_embedder(model_name)
    return model.encode(text, normalize_embeddings=True).tolist()
