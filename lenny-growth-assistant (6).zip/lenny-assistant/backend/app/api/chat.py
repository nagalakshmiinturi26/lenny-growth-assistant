import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agent.agent import GroundedAgent
from app.database import get_db
from app.models.db_models import ChatSession, Message
from app.models.schemas import ChatRequest, ChatResponse
from app.providers.base import ProviderUnavailableError

router = APIRouter(prefix="/api/chat", tags=["Chat"])
logger = logging.getLogger("lenny.chat")

HISTORY_TURNS = 6  # last N messages (user+assistant combined) included as context


async def _load_recent_history(db: AsyncSession, session_id) -> str:
    """Fetch the last few messages in the session, formatted as plain-text
    turns, for follow-up-question context. Kept separate from retrieval —
    only used to resolve pronouns/references, never as a grounding source."""
    result = await db.execute(
        select(Message)
        .where(Message.session_id == session_id)
        .order_by(Message.created_at.desc())
        .limit(HISTORY_TURNS)
    )
    recent = list(reversed(result.scalars().all()))
    if not recent:
        return ""
    lines = [f"{'User' if m.role == 'user' else 'Assistant'}: {m.content}" for m in recent]
    return "\n".join(lines)


@router.post("", response_model=ChatResponse)
async def chat(req: ChatRequest, db: AsyncSession = Depends(get_db)):
    session = await db.get(ChatSession, req.session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session {req.session_id} not found")

    provider_name = req.provider_override or session.llm_provider

    history = await _load_recent_history(db, session.id)

    user_msg = Message(session_id=session.id, role="user", content=req.message, sources={"mode": req.mode})
    db.add(user_msg)
    await db.flush()

    agent = GroundedAgent(db)
    try:
        result = await agent.answer(req.message, req.mode, provider_name, history=history)
    except ProviderUnavailableError as e:
        logger.warning(f"Provider '{provider_name}' unavailable: {e}")
        raise HTTPException(
            status_code=503,
            detail=f"The '{provider_name}' provider is unavailable right now: {e}",
        )
    except Exception as e:
        logger.exception("Unhandled error in agent.answer")
        raise HTTPException(status_code=500, detail=f"Internal error while generating a response: {e}")

    assistant_msg = Message(
        session_id=session.id,
        role="assistant",
        content=result["text"],
        sources={"files": result["sources"], "mode": req.mode, "provider": result["provider_used"]},
    )
    db.add(assistant_msg)
    await db.commit()
    await db.refresh(assistant_msg)

    return ChatResponse(
        message_id=assistant_msg.id,
        answer=result["text"],
        sources=result["sources"],
        provider_used=result["provider_used"],
        mode=req.mode,
    )
