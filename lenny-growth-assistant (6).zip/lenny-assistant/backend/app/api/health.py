import logging

import httpx
from fastapi import APIRouter

from app.config import get_settings
from app.database import db_health

router = APIRouter(tags=["Health"])
logger = logging.getLogger("lenny.health")


@router.get("/api/health")
async def health():
    settings = get_settings()
    db_status = await db_health()

    ollama_status = {"status": "unknown"}
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            ollama_status = {"status": "ok"} if resp.status_code == 200 else {"status": "error"}
    except Exception as e:
        ollama_status = {"status": "unreachable", "detail": str(e)}

    anthropic_status = {"status": "configured" if settings.anthropic_api_key else "not_configured"}

    overall_ok = db_status["status"] == "ok"

    return {
        "status": "ok" if overall_ok else "degraded",
        "database": db_status,
        "ollama": ollama_status,
        "anthropic": anthropic_status,
        "default_provider": settings.default_llm_provider,
    }
