import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class SessionCreate(BaseModel):
    title: str = Field(default="New chat", max_length=200)
    llm_provider: Literal["ollama", "claude"] = "ollama"


class SessionOut(BaseModel):
    id: uuid.UUID
    title: str
    llm_provider: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MessageOut(BaseModel):
    id: uuid.UUID
    role: str
    content: str
    sources: dict
    created_at: datetime

    class Config:
        from_attributes = True


class SessionDetailOut(SessionOut):
    messages: list[MessageOut] = []


class ChatRequest(BaseModel):
    session_id: uuid.UUID
    message: str = Field(min_length=1, max_length=4000)
    mode: Literal["default", "ship30"] = "default"
    provider_override: Literal["ollama", "claude"] | None = None


class ChatResponse(BaseModel):
    message_id: uuid.UUID
    answer: str
    sources: list[str]
    provider_used: str
    mode: str


class ErrorResponse(BaseModel):
    error: str
    detail: str | None = None
