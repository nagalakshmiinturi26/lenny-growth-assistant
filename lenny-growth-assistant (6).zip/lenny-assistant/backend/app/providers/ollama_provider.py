"""
Local provider via Ollama. Tool-calling support varies a lot across the
small local models this is meant to run on (llama3.1:8b, mistral:7b), so
rather than build a tool-use loop we don't trust to work reliably offline,
this provider does direct grounded generation: retrieval happens first
(in the agent layer) and the retrieved context is placed straight into the
prompt. This is a deliberate reliability trade-off for the local path —
documented in the PRD's risks/trade-offs section.
"""
import logging

import httpx

from app.providers.base import BaseLLMProvider, ProviderUnavailableError

logger = logging.getLogger("lenny.providers.ollama")


class OllamaProvider(BaseLLMProvider):
    name = "ollama"

    def __init__(self, base_url: str, model: str):
        self.base_url = base_url.rstrip("/")
        self.model = model

    async def complete(self, system_prompt: str, user_message: str, tools=None) -> dict:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
            "stream": False,
            "options": {"temperature": 0.3},
        }
        try:
            async with httpx.AsyncClient(timeout=90.0) as client:
                resp = await client.post(f"{self.base_url}/api/chat", json=payload)
        except httpx.RequestError as e:
            raise ProviderUnavailableError(
                f"Could not reach Ollama at {self.base_url}. Is `ollama serve` running "
                f"and has `ollama pull {self.model}` been run? ({e})"
            ) from e

        if resp.status_code != 200:
            raise ProviderUnavailableError(f"Ollama returned HTTP {resp.status_code}: {resp.text[:300]}")

        data = resp.json()
        text = data.get("message", {}).get("content", "")
        return {"text": text, "tool_calls": []}
