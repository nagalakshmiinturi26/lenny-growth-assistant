from abc import ABC, abstractmethod
from typing import Any


class ProviderUnavailableError(Exception):
    """Raised when a provider can't be reached (Ollama down, missing API key, timeout)."""


class BaseLLMProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def complete(
        self,
        system_prompt: str,
        user_message: str,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict:
        """
        Returns a dict: {"text": str, "tool_calls": list[dict]}.
        tool_calls is empty for providers/models that don't support tool use
        (the caller falls back to plain grounded generation in that case).
        Must raise ProviderUnavailableError (not a bare exception) on
        connection/timeout/auth failure so the API layer can return a clean
        503 instead of a stack trace.
        """
        raise NotImplementedError
