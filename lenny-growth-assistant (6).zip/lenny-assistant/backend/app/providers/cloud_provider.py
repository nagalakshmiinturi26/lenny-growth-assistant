"""
Cloud provider using the standard Anthropic Messages API (the `anthropic`
package), with tool-use support. This is the provider the agent layer
(app/agent/agent.py) drives its tool-call loop through — see that module,
and the PRD's scope-choices section, for why the Agent SDK itself wasn't
used here.
"""
import logging
from typing import Any

import anthropic

from app.providers.base import BaseLLMProvider, ProviderUnavailableError

logger = logging.getLogger("lenny.providers.cloud")


class AnthropicProvider(BaseLLMProvider):
    name = "claude"

    def __init__(self, api_key: str, model: str):
        if not api_key:
            raise ProviderUnavailableError(
                "ANTHROPIC_API_KEY is not set. Add it to your .env file to use the cloud provider."
            )
        self.client = anthropic.AsyncAnthropic(api_key=api_key)
        self.model = model

    async def complete(
        self,
        system_prompt: str,
        user_message: str,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict:
        try:
            resp = await self.client.messages.create(
                model=self.model,
                max_tokens=2000,
                system=system_prompt,
                messages=[{"role": "user", "content": user_message}],
                tools=tools or [],
            )
        except anthropic.APIConnectionError as e:
            raise ProviderUnavailableError(f"Could not reach the Anthropic API: {e}") from e
        except anthropic.AuthenticationError as e:
            raise ProviderUnavailableError(f"Anthropic API key was rejected: {e}") from e
        except anthropic.RateLimitError as e:
            raise ProviderUnavailableError(f"Anthropic API rate limit hit: {e}") from e

        text_parts = []
        tool_calls = []
        for block in resp.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append({"id": block.id, "name": block.name, "input": block.input})

        return {"text": "\n".join(text_parts), "tool_calls": tool_calls, "raw_stop_reason": resp.stop_reason}

    async def complete_with_tool_result(
        self,
        system_prompt: str,
        user_message: str,
        assistant_tool_use_content: list[dict],
        tool_result_content: list[dict],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict:
        """Second turn of a tool-use loop: feed the tool's result back to the model."""
        try:
            resp = await self.client.messages.create(
                model=self.model,
                max_tokens=2000,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_message},
                    {"role": "assistant", "content": assistant_tool_use_content},
                    {"role": "user", "content": tool_result_content},
                ],
                tools=tools or [],
            )
        except (anthropic.APIConnectionError, anthropic.AuthenticationError, anthropic.RateLimitError) as e:
            raise ProviderUnavailableError(f"Anthropic API call failed: {e}") from e

        text_parts = [b.text for b in resp.content if b.type == "text"]
        return {"text": "\n".join(text_parts), "tool_calls": [], "raw_stop_reason": resp.stop_reason}
