"""
The agent layer. Two intentionally different retrieval paths:

- Claude (cloud): the model is given a `search_transcripts` tool and
  decides when/how to search, via the standard Anthropic tool-use loop.
  This is the "agentic routing" the assignment asks for.
- Ollama (local, mandatory demo path): retrieval always runs first and the
  context is placed directly in the prompt. Small local models are
  unreliable at structured tool-calling, so this path favors reliability
  over agentic flexibility. See docs/PRD.md "Risks and trade-offs".

Both paths converge on the same grounding contract: cite sources, and say
so plainly when the transcript archive doesn't cover the question.
"""
import logging

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import Settings, get_settings
from app.providers.cloud_provider import AnthropicProvider
from app.providers.ollama_provider import OllamaProvider
from app.rag.retriever import TranscriptRetriever
from app.skills.ship30_writer import build_ship30_system_prompt

logger = logging.getLogger("lenny.agent")

BASE_SYSTEM_PROMPT = (
    "You are the Lenny Growth Assistant, a grounded assistant for product "
    "management and growth questions. Answer strictly using the provided "
    "transcript context. After each specific claim, cite its source in the "
    "form [source: filename]. If the context does not contain enough "
    "information to answer, say exactly: 'I do not have sufficient "
    "information in Lenny's podcast archive to answer this.' Do not draw "
    "on outside knowledge."
)

SEARCH_TOOL = {
    "name": "search_transcripts",
    "description": "Search Lenny's Podcast transcript archive for passages relevant to a query.",
    "input_schema": {
        "type": "object",
        "properties": {"query": {"type": "string", "description": "What to search for"}},
        "required": ["query"],
    },
}

NO_INFO_MESSAGE = "I do not have sufficient information in Lenny's podcast archive to answer this."


class GroundedAgent:
    def __init__(self, db: AsyncSession, settings: Settings | None = None):
        self.db = db
        self.settings = settings or get_settings()
        self.retriever = TranscriptRetriever(db)

    def _build_provider(self, provider_name: str):
        if provider_name == "ollama":
            return OllamaProvider(self.settings.ollama_base_url, self.settings.ollama_model)
        if provider_name == "claude":
            return AnthropicProvider(self.settings.anthropic_api_key, self.settings.anthropic_model)
        raise ValueError(f"Unknown provider: {provider_name}")

    async def answer(self, message: str, mode: str, provider_name: str, history: str = "") -> dict:
        system_prompt = BASE_SYSTEM_PROMPT
        if mode == "ship30":
            system_prompt = build_ship30_system_prompt(system_prompt)

        if history:
            system_prompt += (
                "\n\nConversation so far (most recent last):\n"
                f"{history}\n\n"
                "Use this only to resolve references like 'it' or 'that' in the "
                "current question. Ground every factual claim in the retrieved "
                "transcript context below, not in unverified prior turns."
            )

        provider = self._build_provider(provider_name)

        if provider_name == "claude":
            result = await self._answer_via_tool_loop(provider, system_prompt, message)
        else:
            result = await self._answer_direct(provider, system_prompt, message)

        result["provider_used"] = provider_name
        return result

    async def _answer_direct(self, provider, system_prompt: str, message: str) -> dict:
        chunks = await self.retriever.retrieve(message)
        if not chunks:
            return {"text": NO_INFO_MESSAGE, "sources": []}

        context = "\n\n".join(f"[source: {c['source']}] {c['text']}" for c in chunks)
        prompt = f"Context:\n{context}\n\nQuestion: {message}"
        result = await provider.complete(system_prompt, prompt)
        sources = sorted({c["source"] for c in chunks})
        return {"text": result["text"], "sources": sources}

    async def _answer_via_tool_loop(self, provider: AnthropicProvider, system_prompt: str, message: str) -> dict:
        first = await provider.complete(system_prompt, message, tools=[SEARCH_TOOL])

        if not first["tool_calls"]:
            # Model chose not to search - don't trust an ungrounded answer.
            # Fall back to forced retrieval so we never return unsourced content.
            return await self._answer_direct(provider, system_prompt, message)

        call = first["tool_calls"][0]
        query = call["input"].get("query", message)
        chunks = await self.retriever.retrieve(query)

        if chunks:
            tool_result_text = "\n\n".join(f"[source: {c['source']}] {c['text']}" for c in chunks)
            sources = sorted({c["source"] for c in chunks})
        else:
            tool_result_text = "No relevant passages were found in the transcript archive."
            sources = []

        assistant_content = [
            {"type": "tool_use", "id": call["id"], "name": call["name"], "input": call["input"]}
        ]
        tool_result_content = [
            {"type": "tool_result", "tool_use_id": call["id"], "content": tool_result_text}
        ]

        second = await provider.complete_with_tool_result(
            system_prompt, message, assistant_content, tool_result_content, tools=[SEARCH_TOOL]
        )
        return {"text": second["text"] or NO_INFO_MESSAGE, "sources": sources}
