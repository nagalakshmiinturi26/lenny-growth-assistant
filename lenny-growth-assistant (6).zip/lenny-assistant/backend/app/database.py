"""
Database engine/session management.

Design decision: PostgreSQL + the pgvector extension is used for BOTH
relational persistence (sessions/messages) and vector similarity search,
rather than running Postgres alongside a second vector database. One
datastore to operate, back up, and reason about beats two for a system
this size. Documented in architecture.md.
"""
import logging
from contextlib import asynccontextmanager

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import get_settings

logger = logging.getLogger("lenny.db")

settings = get_settings()

engine = create_async_engine(settings.database_url, echo=False, pool_pre_ping=True)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_db():
    """FastAPI dependency: yields a request-scoped DB session."""
    async with AsyncSessionLocal() as session:
        yield session


@asynccontextmanager
async def lifespan_db_init():
    """
    Runs once at app startup: enables pgvector and creates tables if they
    don't exist. For a production handoff this would be replaced by
    Alembic migrations; documented as a known simplification in README.md.
    """
    from app.models.db_models import Base

    try:
        async with engine.begin() as conn:
            await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database ready (pgvector enabled, tables ensured).")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise
    yield


async def db_health() -> dict:
    try:
        async with AsyncSessionLocal() as session:
            await session.execute(text("SELECT 1"))
        return {"status": "ok"}
    except Exception as e:
        return {"status": "error", "detail": str(e)}
