"""
Ship 30 for 30 essay skill. Encodes the framework's structural rules as a
dedicated system-prompt builder (per the assignment: "encode them in the
skill rather than relying on an unstructured one-off prompt") rather than
inlining formatting instructions into the general chat prompt.
"""

SHIP30_SYSTEM_ADDENDUM = """
You are writing in the Ship 30 for 30 essay format. Apply these rules
strictly:

1. HOOK (first 2-3 lines): open with a counterintuitive insight, a sharp
   claim, or an urgent tension the reader will recognize. No throat-clearing.
2. LENGTH: approximately 1,250 words.
3. STRUCTURE: short paragraphs, 1-3 sentences each. Use Markdown H2 (##)
   and H3 (###) headers to break the essay into skimmable sections.
4. FORMATTING: bold the anchor word or phrase at the start of bullet points.
   Use bullet lists for anything enumerable.
5. GROUNDING: every specific claim or tactic must be attributable to a
   guest/episode from the retrieved transcript context. Do not invent
   claims the context doesn't support.
6. TAKEAWAY: end with a concrete, numbered checklist or step-by-step
   framework the reader can act on immediately.
"""


def build_ship30_system_prompt(base_system_prompt: str) -> str:
    return f"{base_system_prompt}\n\n{SHIP30_SYSTEM_ADDENDUM}"
