"""
Central configuration. All values are overridable via environment variables
(see .env.example at the project root). Nothing here has a real secret
default — missing required values fail loudly at startup rather than
silently falling back to something insecure.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- Database ---
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/lenny_assistant"

    # --- LLM provider toggle ---
    # "ollama" (mandatory local demo path) or "claude" (cloud path)
    default_llm_provider: str = "ollama"

    # --- Ollama (local, mandatory for the demo) ---
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.1:8b"

    # --- Anthropic (cloud) ---
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-5"

    # --- Retrieval ---
    embedding_model: str = "all-MiniLM-L6-v2"
    retrieval_top_k: int = 5
    retrieval_similarity_threshold: float = 0.3

    # --- App ---
    log_level: str = "INFO"
    cors_origins: str = "*"


@lru_cache
def get_settings() -> Settings:
    return Settings()
