# Architecture — The Lenny Growth Assistant

## 1. System overview

```
┌───────────┐      HTTP        ┌────────────┐     SQL/pgvector    ┌──────────────┐
│ Frontend  │ ───────────────▶ │  FastAPI   │ ───────────────────▶│ PostgreSQL   │
│ (nginx,   │ ◀─────────────── │  backend   │ ◀────────────────── │ + pgvector   │
│ static)   │                  └─────┬──────┘                     └──────────────┘
└───────────┘                        │
                                      │ tool-use loop (claude) /
                                      │ direct prompt (ollama)
                          ┌───────────┴────────────┐
                          ▼                         ▼
                  ┌───────────────┐        ┌────────────────┐
                  │ Ollama (local)│        │ Anthropic API   │
                  │ mandatory demo│        │ (cloud, opt-in) │
                  └───────────────┘        └────────────────┘
```

## 2. Database schema

**One database, two jobs** — PostgreSQL + pgvector serves both relational
persistence and vector similarity search, rather than running a separate
vector DB alongside it. Simpler ops surface for a system this size; the
trade-off is pgvector's HNSW/IVFFlat indexing is less specialized than a
dedicated vector DB at very large corpus sizes, which is a non-issue for a
single podcast's transcript archive.

- `sessions (id uuid pk, title, llm_provider, created_at, updated_at)`
- `messages (id uuid pk, session_id fk, role, content, sources jsonb, created_at)`
- `transcript_chunks (id serial pk, source_file, episode_title, guest_name, chunk_index, chunk_text, embedding vector(384), created_at)`

`sources` on a message is a JSONB blob: `{"files": [...], "mode": "...", "provider": "..."}`.
Kept schemaless here deliberately — it's audit/debug metadata, not something
queried relationally.

Migrations are **not** using Alembic in this cut — tables are created via
`Base.metadata.create_all` on startup, which is idempotent but not
reversible/versioned. Documented as a known simplification; Alembic would
be the first addition for a real handoff.

## 3. API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | DB, Ollama, and Anthropic-key status |
| POST | `/api/sessions` | Create a session (`title`, `llm_provider`) |
| GET | `/api/sessions` | List sessions, most recently updated first |
| GET | `/api/sessions/{id}` | Fetch a session with its full message history |
| POST | `/api/chat` | Send a message; returns the grounded/Ship30 answer |

Request/response contracts are Pydantic models (`app/models/schemas.py`)
with field-level validation (e.g. message length bounds) — invalid input
returns FastAPI's structured 422, not a 500.

## 4. Ingestion → retrieval flow

1. `.txt`/`.md` files are dropped into `backend/transcripts/`.
2. `scripts/ingest.py` chunks each file (700 chars, 100 overlap — simple
   character-window chunking, not sentence-aware; a reasonable first cut
   given transcripts are informal speech, not structured prose).
3. Each chunk is embedded locally via `sentence-transformers/all-MiniLM-L6-v2`
   (no API cost, works even when both LLM providers are down).
4. Chunks are upserted into `transcript_chunks`, keyed by `source_file` so
   re-running ingestion on an updated file replaces its old chunks instead
   of duplicating them.
5. At query time, `TranscriptRetriever` embeds the query and runs a
   pgvector cosine-distance `ORDER BY ... LIMIT k` query, filtering out
   anything below `RETRIEVAL_SIMILARITY_THRESHOLD`.
6. Every chunk kept is tagged `[source: filename]` before being placed in
   the model's context, and that same source list is returned to the
   frontend and stored in the message's `sources` JSONB — so citations in
   the UI are traceable back to a real ingested file, not model-invented.

## 5. Agent routing and model toggle

`DEFAULT_LLM_PROVIDER` sets a session's default; the frontend's dropdown
lets the evaluator override it per-request (`provider_override` in the
chat request), satisfying "toggle visible in the UI" without requiring an
app restart.

**Why not the Claude Agent SDK:** the SDK wraps the Claude Code CLI and,
by default, hands the model filesystem read/write and bash execution —
tools built for an autonomous coding agent. This product needs exactly
two capabilities (search transcripts, and — as a documented future
extension — write an artifact), so giving it a general-purpose coding
agent's tool surface would be a meaningfully larger and harder-to-audit
attack surface than the task requires. Instead, `app/agent/agent.py` uses
the standard `anthropic` package's Messages API with an explicit,
single-purpose `search_transcripts` tool. This satisfies the assignment's
underlying ask — "agentic architecture with clear skill boundaries and
reliable routing" — with a tool surface scoped to what the product
actually does.

**Two different retrieval strategies by provider, on purpose:**
- **Claude (cloud):** the model receives the `search_transcripts` tool
  and decides whether/how to call it; if it answers without calling it,
  the agent treats that as ungrounded and forces a direct-retrieval
  fallback rather than trusting an unsourced answer.
- **Ollama (local, mandatory demo path):** retrieval always runs first,
  and results are placed directly in the prompt. Small local models
  (llama3.1:8b, mistral:7b) are inconsistent at structured tool-calling;
  rather than build a tool loop we don't trust to work offline, the local
  path trades agentic flexibility for reliability. This is called out
  explicitly in `PRD.md`'s risk table, not hidden.

## 6. Ship 30 for 30 skill boundary

`app/skills/ship30_writer.py` is a pure prompt-construction module with no
side effects — it takes a base system prompt and returns an extended one
encoding the Ship 30 structural rules (hook, ~1250 words, short
paragraphs, bold anchors, checklist ending). Keeping this as a separate,
testable unit — rather than an inline string in the chat handler — is
what "encode them in the skill" means in practice here: the formatting
rules can be unit-tested and reused independently of which provider
answers.

## 7. Artifact rendering and security

Two artifact types are supported by the frontend's rendering code:

- **Markdown** (used today, for Ship 30 essays): rendered client-side via
  a small in-house formatter — plain text in, so there's no injection
  surface to sanitize beyond standard `textContent`-based HTML-escaping,
  which the renderer does before any formatting is applied.
- **Raw HTML/CSS** (reference implementation, not yet wired to a chat
  mode — see `PRD.md` scope): rendered in an `<iframe>` with
  `sandbox="allow-scripts"` and **no** `allow-same-origin`. Omitting
  `allow-same-origin` is the key control — it means even if a script runs
  inside the iframe, it cannot read the parent page's cookies,
  localStorage, or DOM, and is treated as opaque-origin by the browser.
  Content is additionally passed through DOMPurify client-side before
  being placed in `srcdoc`, as defense in depth against the sandbox
  attribute being misconfigured or removed by a future edit. What this
  **permits**: the artifact can run its own scripts and style itself
  freely. What it **blocks**: reading/writing anything belonging to the
  parent page, and (implicitly, since no `allow-same-origin`) that content
  can't make authenticated requests back to the app on the user's behalf.

## 8. Security and secrets

- No secrets in the repo: `.env` is git-ignored; `.env.example` ships
  with empty/placeholder values only.
- `ANTHROPIC_API_KEY` lives only in the backend process's environment; it
  is never sent to or readable from the frontend.
- CORS is wide open (`*`) for local/demo purposes — documented as
  something a real deployment would lock to a specific origin.

## 9. Deployment topology

`docker-compose.yml` brings up four services: `db` (Postgres+pgvector),
`ollama`, `backend` (FastAPI), `frontend` (nginx serving the static page).
`backend` waits on `db`'s healthcheck before starting. The one manual step
after `docker-compose up` is pulling an Ollama model
(`docker exec -it lenny_ollama ollama pull llama3.1:8b`) — documented in
the README rather than baked into the image, since baking a multi-GB
model into a container significantly slows every rebuild.

## 10. Observability and resilience

- Structured logging (`logging`, one logger per module: `lenny.agent`,
  `lenny.chat`, `lenny.retriever`, etc.) at a configurable `LOG_LEVEL`.
- `/api/health` reports DB, Ollama reachability, and whether an Anthropic
  key is configured — enough to diagnose "which piece is actually down"
  without reading logs.
- A global FastAPI exception handler ensures any unhandled error returns
  structured JSON (`{"error": ..., "detail": ...}`), never a bare 500 with
  no body.
- Provider failures (Ollama unreachable, bad/missing Anthropic key, rate
  limit) are raised as a dedicated `ProviderUnavailableError` and mapped
  to a 503 with a human-readable cause — distinct from a 500, so the
  frontend (and an evaluator reading logs) can tell "expected
  unavailability" apart from "actual bug."
- Empty retrieval results are not an error — they produce the explicit
  "insufficient information" answer, by design (see PRD acceptance
  criteria).
