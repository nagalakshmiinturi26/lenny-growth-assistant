# Design — The Lenny Growth Assistant

## 1. UI/UX principles

- **Two-pane, always visible.** Chat on the left, artifact preview on the
  right — mirrors the Claude Artifacts pattern the client referenced, so
  generated content (the Ship 30 essay) is never buried in a scrolling
  chat log.
- **No hidden state.** The active model provider is a visible dropdown,
  not a config file the user has to know exists. Every answer's source
  files and provider are shown inline, not just logged server-side.
- **Fail loud, fail readable.** Every failure mode (no session, backend
  unreachable, provider down, empty response) renders a distinct,
  human-readable message in the chat pane — never a silent no-op, never a
  raw stack trace in the UI.

## 2. Information architecture

```
┌─────────────────────────────┬───────────────────────────┐
│ Chat pane                   │ Artifact pane              │
│  - provider dropdown        │  - Markdown essay render   │
│  - message history          │    (default)               │
│  - input + Ask / Ship30     │  - sandboxed HTML iframe    │
│    buttons                  │    (reference impl, see    │
│                              │    architecture.md)        │
└─────────────────────────────┴───────────────────────────┘
```

- A session is created lazily on the first message, not on page load —
  avoids creating empty rows for every visit.
- Messages are appended client-side immediately (optimistic user bubble)
  and the bot bubble fills in once the backend responds.

## 3. Key interaction states

| State | What the user sees |
|---|---|
| Sending first message | User bubble appears immediately; session is created behind the scenes |
| Normal grounded answer | Bot bubble with cited sources + provider badge |
| No relevant transcript content | Bot bubble with the explicit "I do not have sufficient information..." message |
| Ship 30 mode | Bot bubble confirms generation; full essay renders in the artifact pane as formatted Markdown |
| Backend unreachable | Red error bubble naming the expected backend URL |
| Provider unavailable (Ollama down / no Claude key) | Red error bubble with the specific reason (503 detail from the API), not a generic failure |
| Session creation fails | Red error bubble before any chat call is attempted |

## 4. Responsive behavior

The two-pane layout is built with flexbox at `flex: 1` on each pane, so it
resizes naturally down to tablet widths. Below a certain width a true
mobile layout (stacked panes with a tab switcher) would be the next
iteration — not built here, since the assignment's demo is a desktop/local
evaluation flow. Noted as a known gap rather than left unstated.

## 5. Accessibility considerations

- All interactive elements (`input`, `select`, `button`) are native HTML
  form controls, so they carry keyboard focus and screen-reader semantics
  for free rather than needing ARIA roles bolted on.
- Enter key submits the chat input (no mouse-only interaction path).
- Color is never the only signal for state — error messages carry text
  ("Error (503): ...") in addition to the red background.
- Known gap: no explicit `aria-live` region on the messages list, so a
  screen reader won't automatically announce new bot replies. Flagged as
  a next step rather than silently omitted.

## 6. Design decisions worth calling out

- **No CSS framework.** A single inline stylesheet keeps the frontend
  dependency-free (just DOMPurify, loaded from a CDN, for artifact
  sanitization) — deliberately avoiding a Next.js/Tailwind build pipeline
  for a demo this scoped. See `architecture.md` for the reasoning.
- **Plain-text over rendered Markdown in the main chat bubbles** would
  have been simpler, but grounded answers frequently contain bullet lists
  and bold citations that are meaningfully harder to scan as raw text —
  hence the small in-house Markdown renderer used for both the chat
  bubbles and the artifact pane.
