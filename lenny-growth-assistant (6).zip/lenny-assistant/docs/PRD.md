# PRD — The Lenny Growth Assistant

## 1. User and problem

**Primary user:** a Growth PM or product lead who wants actionable tactics
from Lenny's Podcast without listening to 200+ hours of audio, and who
needs to turn what they learn into shareable written content (an internal
memo, a Slack post, a team doc) without manually re-writing it.

**Job to be done:** "When I have a specific growth or product question,
let me get a grounded, cited answer from the podcast archive in under a
minute, and optionally turn that answer into a polished essay I can post
or forward."

**Pain removed:** hours of scrubbing through podcast audio/transcripts
looking for a specific tactic or quote, and the separate effort of turning
notes into something presentable.

## 2. Success metrics

- **Retrieval grounding rate:** ≥ 90% of answers either cite a real
  transcript source or explicitly say the archive doesn't cover the
  question (never a confident, unsourced answer).
- **Local inference latency:** first token in < 4s on the mandatory Ollama
  demo path, on a machine meeting the minimum hardware spec.
- **Artifact render safety:** 0 script-injection or storage-access
  incidents from the artifact viewer's sandboxing.

## 3. Assumptions

The client brief didn't specify these, so the following were assumed:

- **Single-user, local-first deployment.** No auth/multi-tenant support —
  the assistant runs on one evaluator's machine. Documented as a scope
  exclusion, not an oversight.
- **Transcript corpus is provided as local `.txt`/`.md` files** the
  evaluator drops into `backend/transcripts/`, rather than a live scrape
  of Lenny's Substack (no license terms were given for scraping the site
  directly, so ingestion is designed around a local file drop instead).
- **"Agent layer" is satisfied by a bounded tool-use loop** (Anthropic
  Messages API tool-calling) rather than the full Claude Agent SDK. The
  Agent SDK wraps the Claude Code CLI and grants filesystem/bash access by
  default — appropriate for a coding agent, not for a QA product with a
  narrow, auditable tool surface. See `architecture.md` for detail.
- **Local model quality is lower than cloud.** llama3.1:8b will sometimes
  produce weaker citations or looser adherence to the Ship 30 format than
  Claude does. This is treated as an accepted trade-off of the local path,
  not a bug to hide — the UI shows which provider answered.

## 4. Scope choices

**In scope:**
- Grounded QA over ingested transcripts, with citations
- Session persistence (Postgres)
- Ship 30 for 30 essay generation as a distinct skill/mode
- Dual provider (Ollama local / Claude cloud) with a visible UI toggle
- Markdown artifact rendering (the essay output) in a side panel
- A reference implementation of sandboxed HTML artifact rendering
  (DOMPurify + `sandbox="allow-scripts"` without `allow-same-origin`),
  even though no current chat mode emits raw HTML artifacts yet
- Docker Compose one-command startup, health endpoint, structured logs,
  basic automated tests

**Out of scope (explicitly excluded):**
- Multi-user auth/access control
- Automated transcript scraping/refresh pipeline (ingestion is manual,
  from local files)
- A model-generated raw-HTML artifact mode wired end-to-end (the
  rendering path exists and is documented, but no skill currently
  produces that artifact type — flagged as a natural next increment)
- Streaming token-by-token responses (the API returns a complete answer;
  streaming would improve perceived latency but adds meaningful
  complexity for a first cut)

## 5. Flows

1. **Ask a question:** user opens the app → a session is created on first
   message → question is sent to `/api/chat` → agent retrieves relevant
   chunks → provider generates a grounded, cited answer → answer + sources
   render in the chat pane.
2. **Generate an essay:** user clicks "Ship 30 Essay" → same retrieval
   path, but the system prompt is extended with the Ship 30 skill's
   formatting rules → the resulting Markdown renders in the artifact
   panel, not just the chat bubble.
3. **Switch providers:** user changes the model dropdown → next message
   is answered by that provider; if it's unavailable (Ollama not running,
   or no Anthropic key set), the user sees a clear error, not a hang or a
   stack trace.

## 6. Acceptance criteria

- A question with no relevant transcript content returns the explicit
  "I do not have sufficient information..." message, not a hallucinated
  answer.
- Every grounded answer lists at least one source file.
- Switching to "claude" without `ANTHROPIC_API_KEY` set returns a 503
  with a human-readable message, not a 500 or a hang.
- Stopping the `ollama` container and asking a question on the local
  provider returns a 503 explaining Ollama is unreachable, within the
  HTTP client's timeout window.
- `docker-compose up` brings up db + backend + frontend + ollama without
  manual intervention beyond `ollama pull` and populating `.env`.

## 7. Risks and trade-offs

| Risk | Mitigation / accepted trade-off |
|---|---|
| Hallucination | System prompt enforces citation-or-refusal; retrieval threshold drops low-similarity chunks before they reach the model |
| Local model quality (8B params) | Documented as an accepted trade-off of the mandatory local demo path; cloud path available for higher-quality output |
| Latency (local CPU inference) | 90s client timeout on the Ollama call, with a clear error rather than an indefinite hang |
| Cost (cloud path) | Cloud provider is opt-in per session, not default |
| Unsafe artifact rendering | Sandboxed iframe (`allow-scripts` only) + DOMPurify; documented as the pattern for any future HTML-artifact skill |
| Data/key leakage | `.env` is gitignored; `.env.example` ships with no real secrets; API key never sent to the frontend |
